import Link from "next/link";
import { JsonLd, breadcrumbSchema } from "@/components/json-ld";
import { getProjects, getSettings } from "@/lib/queries";
import { getServerLocale } from "@/lib/server-locale";
import { pick } from "@/lib/types";

export default async function ProjectsPage() {
  const { locale, dict } = await getServerLocale();
  const settings = getSettings();
  const projects = getProjects();
  const siteUrl = process.env.PRONET_SITE_URL || "http://localhost:3000";

  const grouped = new Map<string, typeof projects>();
  for (const p of projects) {
    const key = p.category || dict.pages.projectsGeneral;
    if (!grouped.has(key)) grouped.set(key, []);
    grouped.get(key)!.push(p);
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <JsonLd
        data={breadcrumbSchema([
          { name: dict.nav.home, url: siteUrl },
          { name: dict.pages.projectsTitle, url: `${siteUrl}/projects` },
        ])}
      />

      <header>
        <h1 className="text-3xl font-black text-ink">{dict.pages.projectsTitle}</h1>
        <p className="mt-3 max-w-3xl text-sm leading-7 text-ink-muted">{dict.pages.projectsIntro}</p>
      </header>

      <div className="mt-8 space-y-10">
        {[...grouped.entries()].map(([category, items]) => (
          <section key={category} aria-labelledby={`cat-${category}`}>
            <h2 id={`cat-${category}`} className="mb-4 text-xl font-black text-brand-strong">
              {category}
            </h2>
            <ul className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {items.map((p) => (
                <li key={p.id} className="panel flex flex-col p-6">
                  <h3 className="text-base font-black leading-6 text-ink">{pick(locale, p.title, p.titleEn)}</h3>
                  <p className="mt-3 flex-1 text-sm leading-7 text-ink-soft">{pick(locale, p.desc, p.descEn)}</p>
                  <p className="mt-4 text-xs font-bold text-ink-muted">📍 {p.location}</p>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>

      <section className="panel mt-12 p-8 text-center">
        <h2 className="text-2xl font-black text-ink">{dict.pages.projectsCtaTitle}</h2>
        <p className="mx-auto mt-3 max-w-2xl text-sm leading-7 text-ink-soft">{dict.pages.projectsCtaBody}</p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Link href="/contact" className="btn-primary text-sm">
            {dict.pages.projectsCtaBtn}
          </Link>
          <a
            href={`https://wa.me/${settings.whatsappNumber.replace(/[^0-9]/g, "")}?text=${encodeURIComponent(dict.pages.projectsWhatsappMsg)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-ghost text-sm"
          >
            💬 {dict.pages.whatsapp}
          </a>
        </div>
      </section>
    </div>
  );
}
